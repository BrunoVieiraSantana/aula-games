# Mario Jump 🍄

![gif minigame](https://github.com/Driellynepo/GOGPG/assets/141869927/025db4e5-0c6f-44de-8613-2970ad1a1c19)
## Sobre o projeto 
Teste seus reflexos com o Mario Jump! Este é um minigame simples onde seu objetivo é fazer o personagem pular sobre os obstáculos usando a tecla de espaço para alcançar a maior pontuação possível. Você pode verificar sua pontuação no canto superior esquerdo da tela. Se você atingir um obstáculo, o jogo será encerrado, mas não se preocupe! Você pode clicar em "Restart Game" e tentar novamente. 

## Como executar
Para experimentar o minigame visite: 
https://driellynepo.github.io/MarioJump.github.io/</br>

## Densenvolvido com:

![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) </br>
![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white)</br>
![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white)
